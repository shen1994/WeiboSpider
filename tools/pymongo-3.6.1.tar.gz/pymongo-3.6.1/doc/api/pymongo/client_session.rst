:mod:`client_session` -- Logical sessions for sequential operations
===================================================================

.. automodule:: pymongo.client_session
   :members:
