:mod:`change_stream` -- Watch changes on a collection
=====================================================

.. automodule:: pymongo.change_stream
   :members:
