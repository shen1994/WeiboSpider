:mod:`pool` -- Pool module for use with a MongoDB client.
==============================================================

.. automodule:: pymongo.pool
   :synopsis: Pool module for use with a MongoDB client.
   :members:
