
"""
Obsolete module, kept for giving a meaningful error message when trying to
import.
"""

raise ImportError("scrapy.stats usage has become obsolete, use "
                  "`crawler.stats` attribute instead")
